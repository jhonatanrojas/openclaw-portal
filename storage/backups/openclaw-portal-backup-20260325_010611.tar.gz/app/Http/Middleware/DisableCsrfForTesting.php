<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class DisableCsrfForTesting extends Middleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Deshabilitar CSRF completamente para todas las rutas
        if ($request->is('test-login') || $request->is('login') || $request->is('*/login')) {
            return $next($request);
        }
        
        return parent::handle($request, $next);
    }
    
    /**
     * Determine if the request has a URI that should pass through CSRF verification.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function inExceptArray($request)
    {
        // Agregar todas las rutas que queremos excluir de CSRF
        $except = [
            'test-login',
            'login',
            '*/login',
            'api/*',
            'test'
        ];
        
        foreach ($except as $pattern) {
            if ($request->is($pattern)) {
                return true;
            }
        }
        
        return false;
    }
}
