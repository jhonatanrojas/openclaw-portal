<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    return view('welcome');
});

// Ruta de prueba simple
Route::get('/test', function () {
    return response()->json([
        'status' => 'ok',
        'message' => 'Test route working',
        'session_id' => session_id(),
        'csrf_token' => csrf_token(),
        'app_url' => config('app.url'),
        'session_domain' => config('session.domain'),
    ]);
});

// Ruta de login de prueba (sin CSRF)
Route::post('/test-login', function () {
    $credentials = request()->only('email', 'password');
    
    if ($credentials['email'] === 'admin@openclaw.test' && $credentials['password'] === 'password') {
        return response()->json([
            'status' => 'success',
            'message' => 'Login successful',
            'redirect' => '/simple-dashboard',
            'user' => [
                'id' => 1,
                'name' => 'Administrator',
                'email' => 'admin@openclaw.test'
            ]
        ]);
    }
    
    return response()->json([
        'status' => 'error',
        'message' => 'Invalid credentials'
    ], 401);
});

// Login simple (vista)
Route::get('/simple-login', function () {
    return view('simple-login');
});

// Dashboard simple (vista)
Route::get('/simple-dashboard', function () {
    return view('simple-dashboard', [
        'user' => (object)[
            'id' => 1,
            'name' => 'Administrator',
            'email' => 'admin@openclaw.test'
        ]
    ]);
});

// Comentar temporalmente las rutas de autenticación de Breeze
// require __DIR__.'/auth.php';
